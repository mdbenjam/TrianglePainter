"""

=================
How to Find Stuff
=================

How to find things in NumPy.

"""
